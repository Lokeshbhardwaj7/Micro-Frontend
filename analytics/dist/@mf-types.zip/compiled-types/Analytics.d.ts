import React from 'react';
declare const Analytics: React.FC;
export default Analytics;
