import React from 'react';
declare const UserManagement: React.FC;
export default UserManagement;
