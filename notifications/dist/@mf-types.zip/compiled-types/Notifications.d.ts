import React from 'react';
declare const Notifications: React.FC;
export default Notifications;
